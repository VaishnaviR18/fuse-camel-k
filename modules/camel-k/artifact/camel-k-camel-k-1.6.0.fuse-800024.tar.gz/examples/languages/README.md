# Supported languages Camel K examples

Find useful examples about how to develop a Camel K integration in `Java`, `Javascript`, `Groovy`, `XML` and `YAML`.