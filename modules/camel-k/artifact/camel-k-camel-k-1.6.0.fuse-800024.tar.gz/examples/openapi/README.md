# Open API Camel K examples

Find useful examples about how to expose an Open API specification in a Camel K integration.