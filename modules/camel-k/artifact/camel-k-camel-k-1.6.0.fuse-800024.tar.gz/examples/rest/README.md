# Rest Camel K examples

Find useful examples about how to Produce/Consume RESTful webservices in a Camel K integration.