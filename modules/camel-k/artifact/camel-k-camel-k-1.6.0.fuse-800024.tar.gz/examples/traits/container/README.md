# Camel K Container Trait

In this section you will find examples about fine tuning your `Integration` using **Container** `trait` capability.
